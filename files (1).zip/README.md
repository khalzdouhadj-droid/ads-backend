# دليل تشغيل ربط الإعلانات (Meta Ads + TikTok Ads)

هذا الدليل مكتوب لشخص بلا أي خلفية برمجية. اتبعي الخطوات بالترتيب بالضبط.
كل خطوة تستغرق دقائق، والمجموع تقريبا ساعة إلى ساعتين (أغلبها انتظار موافقات).

---

## الجزء 1: رفع السيرفر على الإنترنت (استضافة مجانية)

السيرفر هو الكود اللي جهزناه، خاصو "يخدم" 24 على 24 على الإنترنت، مش بروك على كمبيوترك.
غادي نستعملو **Render.com** (فيه باقة مجانية، وسهل بزاف).

1. روحي لـ **render.com** وسجلي حساب جديد (تقدري تدخلي بحساب GitHub أو بالإيميل).
2. إذا ما عندكش حساب **GitHub**، سجلي واحد في **github.com** (مجاني).
3. فـ GitHub، ديري "New repository"، سميه مثلا `ads-backend`، واختاري "Public" أو "Private".
4. رفعي فيه كل الملفات اللي فـ هذا المجلد (`ads-backend`) — GitHub فيه زر "Upload files"، جري الملفات كاملين لتما.
5. رجعي لـ Render، دوسي "New +" ثم "Web Service".
6. اربطي حساب GitHub ديالك واختاري الـ repository اللي رفعتي (`ads-backend`).
7. فـ الإعدادات:
   - Build Command: `npm install`
   - Start Command: `npm start`
8. دوسي "Create Web Service". Render غادي يعطيك رابط شبيه بـ:
   `https://ads-backend-xxxx.onrender.com`
   **احتفظي بهذا الرابط** — راح تحتاجيه فـ كل الخطوات الجاية.

---

## الجزء 2: ربط حساب Meta Ads (فيسبوك/انستغرام)

1. روحي لـ **developers.facebook.com** وسجلي دخول بحسابك ديال فيسبوك.
2. دوسي "My Apps" ثم "Create App".
3. اختاري نوع التطبيق "Business"، وسميه (مثلا: اسم متجرك).
4. مرة يتصنع التطبيق، دوسي على "Add Product" ولقي "Marketing API" وزيديها.
5. من إعدادات التطبيق (Settings > Basic)، هتلقي:
   - **App ID** (رقم)
   - **App Secret** (كلمة سر، دوسي "Show" باش تبينلك)
   - انسخيهم لتما، راح تحتاجيهم.
6. فـ نفس صفحة الإعدادات، لقي "Valid OAuth Redirect URIs" وزيدي هذا الرابط:
   `https://ads-backend-xxxx.onrender.com/auth/meta/callback`
   (بدلي `ads-backend-xxxx` بالرابط الحقيقي ديالك من الجزء 1)
7. خاصك تعرفي رقم "حساب الإعلانات" ديالك (Ad Account ID): روحي لـ **business.facebook.com**، فـ الإعدادات > "Ad Accounts"، راح تلقي رقم يبدا بـ `act_123456789` — خديها بلا `act_`.

**دابا فـ Render:**
8. رجعي لـ Render، دوسي على السيرفر ديالك، ثم "Environment".
9. زيدي هاذو المتغيرات (Environment Variables):
   - `META_APP_ID` = الرقم من خطوة 5
   - `META_APP_SECRET` = الكلمة من خطوة 5
   - `META_REDIRECT_URI` = الرابط من خطوة 6
   - `META_AD_ACCOUNT_ID` = الرقم من خطوة 7
10. احفظي، Render غادي يعاود تشغيل السيرفر بروحو.

**آخر خطوة:**
11. افتحي فـ المتصفح: `https://ads-backend-xxxx.onrender.com/auth/meta/login`
12. راح توديك لصفحة فيسبوك تطلب منك الموافقة على صلاحيات الإعلانات — دوسي "متابعة"/"Continue".
13. إذا شفتي "تم ربط حساب Meta Ads بنجاح" — مبروك، الحساب مربوط.

---

## الجزء 3: ربط حساب TikTok Ads

1. روحي لـ **business-api.tiktok.com** وسجلي حساب مطور (TikTok for Business Developer).
2. أنشئي تطبيق جديد (Create an App).
3. من صفحة التطبيق، انسخي:
   - **App ID**
   - **Secret**
4. فـ إعدادات التطبيق، زيدي "Redirect URI":
   `https://ads-backend-xxxx.onrender.com/auth/tiktok/callback`
5. خاصك رقم "Advertiser ID" ديالك — تلقاه فـ حساب TikTok Ads Manager ديالك، فـ الإعدادات.

**فـ Render:**
6. زيدي هاذو المتغيرات:
   - `TIKTOK_APP_ID`
   - `TIKTOK_APP_SECRET`
   - `TIKTOK_REDIRECT_URI`
   - `TIKTOK_ADVERTISER_ID`

**آخر خطوة:**
7. افتحي: `https://ads-backend-xxxx.onrender.com/auth/tiktok/login`
8. وافقي، وإذا شفتي رسالة النجاح — الحساب مربوط.

---

## الجزء 4: ربط لوحة التحكم (الفرونت اند) بالسيرفر

فـ لوحة التحكم ديالك (ملف `store_dashboard.jsx`)، خاصك تزيدي كود يجيب البيانات من السيرفر، مثلا:

```javascript
const res = await fetch("https://ads-backend-xxxx.onrender.com/auth/meta/campaigns");
const data = await res.json();
```

هذي الخطوة تقنية شوية أكثر (ربط الواجهة بالبيانات الحقيقية وعرضها فـ جدول أو رسم بياني).
إذا حسيتي بصعوبة هنا، هذا بالضبط اللي يقدر يديرلك مطور مستقل فـ ساعة أو ساعتين خدمة،
لأن كل الأساس (السيرفر، الربط مع Meta وTikTok) راهو جاهز.

---

## ملاحظات مهمة

- **الأمان**: لا تشاركي ملف `.env` أو الـ App Secret مع أي حد.
- **الباقة المجانية فـ Render** تربد (تتوقف) إذا محدش استعملها لمدة، وتاخد بضع ثواني باش ترجع تخدم عند أول طلب — عادي، ماشي خطأ.
- **إذا رسالة خطأ**: أغلب الأخطاء سببها متغير بيئة (Environment Variable) ناقص أو غلط — تأكدي من الخطوات فـ الجزء 2 و3.
- هذا السيرفر يخدم لحساب واحد (متجر واحد). إذا بغيتي عدة متاجر/مستخدمين، خاص تعديل إضافي (قاعدة بيانات حقيقية بدل ملف tokens.json).
